package com.example.top10downloader

import android.content.Context
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.ListView
import java.net.URL

class MainActivity : AppCompatActivity() {

    var TAG:String="ParseApp"
    private var url: String ="https://www.google.com"
    var modifiedurl = "" + url

    var xmlListView: ListView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        var count: Int = 0
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        xmlListView = findViewById<ListView>(R.id.xmlListView)


        var downloadData:Downloaddata = Downloaddata()
        downloadData.execute("http://ax.itunes.apple.com/WebObjects/MZStoreServices.woa/ws/RSS/topsongs/limit=10/xml")
        Log.d(TAG,"finished onCreate")

    }

    private inner class Downloaddata() : AsyncTask<String, Void, String>() {
        override fun doInBackground(vararg p0: String?): String {
            Log.d(TAG, "we call the url ${p0.toString()}")
            var xmlString: String = URL(p0[0]).readText()
            return xmlString
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            val parseapplication: Parseapp = Parseapp()
            var FeedEntrylist = parseapplication.parse(result)

            val feedAdapter = FeedAdapter(applicationContext, R.layout.item_list, FeedEntrylist)
            xmlListView!!.adapter=feedAdapter
            Log.d(TAG,"finished downloading url"+result)
        }

    }
}