package com.example.top10downloader

class Downloaddata {
    fun download() {
        val main: MainActivity = MainActivity()
        val downloaddata: Double
    }
}